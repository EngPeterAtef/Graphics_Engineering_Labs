#pragma once

struct Color {
    uint8_t r, g, b, a;
};